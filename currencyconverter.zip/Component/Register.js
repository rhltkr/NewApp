import React,{useState} from 'react'
import { ScrollView,Text, View,StyleSheet,TouchableOpacity, TextInput,Alert } from 'react-native'

const Register = ({navigation})=> {
    
    const [userName,setUserName] = useState("");
    const [Name,setName] = useState("");
    const [Email,setEmail] = useState("");
    const [userPassword,setUserPassword] = useState("");
    const [userRePassword,setUserRePassword] = useState("");
    const Submit =()=>{
        if(userName == "" || userPassword =="" || Email == "" || userRePassword=="" || Name == ""){
            Alert.alert("Please Enter All Fileds");
            
        }
        else{
            if(userPassword != userRePassword){
                Alert.alert("Password and RePassword did not Match");
            }
            else{
                navigation.navigate('Login',{username:`${userName}`,Password:`${userPassword}`,email:`${Email}`,name:`${Name}`})
            }
        }
    }
    return (
        <ScrollView backgroundColor={"#fff"}
        KeyboardShouldPersistTaps="handled">
            <View style={Styles.mainContainer}>
        <Text style={Styles.mainHeader}>Register</Text>
        <View style={Styles.inputContainer}>
            <Text style={Styles.label}>Enter Username</Text>
            <TextInput style={Styles.inputStyle}
                autoCapitalize="none"
                autoCorrect={false}
                value={userName}
                onChangeText={(actualValue)=>setUserName(actualValue)}
            />
        </View>
        <View style={Styles.inputContainer}>
            <Text style={Styles.label}>Enter Name</Text>
            <TextInput style={Styles.inputStyle}
                autoCapitalize="none"
                autoCorrect={false}
                value={Name}
                onChangeText={(actualValue)=>setName(actualValue)}
            />
        </View>
        <View style={Styles.inputContainer}>
            <Text style={Styles.label}>Enter Email</Text>
            <TextInput style={Styles.inputStyle}
                autoCapitalize="none"
                autoCorrect={false}
                value={Email}
                onChangeText={(actualValue)=>setEmail(actualValue)}
            />
        </View>
        <View style={Styles.inputContainer}>
            <Text style={Styles.label}>Enter Password</Text>
            <TextInput style={Styles.inputStyle}
                autoCapitalize="none"
                autoCorrect={false}
                secureTextEntry={true}
                value={userPassword}
                onChangeText={(actualValue)=>setUserPassword(actualValue)}
            />
        </View>
        <View style={Styles.inputContainer}>
            <Text style={Styles.label}>Re-Enter Password</Text>
            <TextInput style={Styles.inputStyle}
                autoCapitalize="none"
                autoCorrect={false}
                secureTextEntry={true}
                value={userRePassword}
                onChangeText={(actualValue)=>setUserRePassword(actualValue)}
            />
        </View>
        <View style={Styles.wrapperText}>
            <TouchableOpacity style={Styles.buttonStyle} onPress={()=>Submit()}>
                <Text style={Styles.buttonText}>Register</Text>
            </TouchableOpacity>
        </View>
            </View>
        </ScrollView>
      
    )
}

const Styles =StyleSheet.create({
    mainContainer:{
        height:"100%",
        paddingHorizontal:30,
        backgroundColor:"#fff",
    },
    mainHeader:{
        fontSize:25,
        color:"#344055",
        fontWeight:"500",
        textTransform:"capitalize",
        fontStyle:"bold",
        textAlign:'center',

    },
    inputContainer:{marginTop:20},
    label:{
        fontSize:18,
        color:"#7d7d7d",
        marginTop:10,
        marginBottom:5,
        lineHeight:25,
    },
    inputStyle:{
        borderWidth:1,
        borderColor:"rgba(0,0,0,0.3)",
        paddingHorizontal:15,
        paddingVertical:7,
        borderRadius:1,
        fontSize:18,
    },
    buttonStyle:{
        margin:10,
    },
    buttonText:{
        backgroundColor:"black",
        padding:10,
        textAlign:"center",
        fontSize:20,
        color:"white",
        borderRadius:10,
        margin:10,
    }
})

export default Register;

