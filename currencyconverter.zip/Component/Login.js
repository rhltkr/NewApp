import React,{useState} from 'react'
import { Text, View,StyleSheet,TouchableOpacity, TextInput, Alert } from 'react-native'

const Login = ({navigation,route})=> {
    const username = route.params.username;
    const password = route.params.Password;
    const [userName,setUserName] = useState("");
    const [userPassword,setUserPassword] = useState("");
    const Submit =()=>{
        if(userName == username && userPassword == password){
            Alert.alert("Welcome");
            navigation.navigate("Home",{myName:`${userName}`})
        }
        else if(userName == ""){
            Alert.alert("please enter Username")
        }
        else if(userPassword == ""){
            Alert.alert("please enter Password")
        }
        else{
            Alert.alert("Wrong Credential")
        }
    }
    return (
        
      <View style={Styles.mainContainer}>
        <Text style={Styles.mainHeader}>Login</Text>
        <View style={Styles.inputContainer}>
            <Text style={Styles.label}>Enter Username</Text>
            <TextInput style={Styles.inputStyle}
                autoCapitalize="none"
                autoCorrect={false}
                value={userName}
                onChangeText={(actualValue)=>setUserName(actualValue)}
            />
        </View>
        <View style={Styles.inputContainer}>
            <Text style={Styles.label}>Enter Password</Text>
            <TextInput style={Styles.inputStyle}
                
                secureTextEntry={true}
                autoCapitalize="none"
                autoCorrect={false}
                value={userPassword}
                onChangeText={(actualValue)=>setUserPassword(actualValue)}
            />
        </View>
        
        <View style={Styles.wrapperText}>
            <TouchableOpacity style={Styles.buttonStyle}
                onPress={()=>Submit()}
            >
                <Text style={Styles.buttonText}>Login</Text>
            </TouchableOpacity>
        </View>
      </View>
    )
}

const Styles =StyleSheet.create({
    mainContainer:{
        height:"100%",
        paddingHorizontal:30,
        paddingTop:30,
        backgroundColor:"#fff",
    },
    mainHeader:{
        fontSize:25,
        color:"#344055",
        fontWeight:"500",
        paddingTop:20,
        paddingBottom:15,
        textTransform:"capitalize",
        fontStyle:"bold",
        textAlign:'center',

    },
    inputContainer:{marginTop:20},
    label:{
        fontSize:18,
        color:"#7d7d7d",
        marginTop:10,
        marginBottom:5,
        lineHeight:25,
    },
    inputStyle:{
        borderWidth:1,
        borderColor:"rgba(0,0,0,0.3)",
        paddingHorizontal:15,
        paddingVertical:7,
        borderRadius:1,
        fontSize:18,
    },
    buttonStyle:{
        margin:10,
    },
    buttonText:{
        backgroundColor:"black",
        padding:10,
        textAlign:"center",
        fontSize:20,
        color:"white",
        borderRadius:10,
        margin:10,
    }
})

export default Login;

