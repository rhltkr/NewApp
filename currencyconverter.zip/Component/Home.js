import React, {useState} from 'react'
import { ScrollView,
    View,
    Text,
    TouchableOpacity,
    StyleSheet,
    SafeAreaView,
    TextInput,
    Alert } from 'react-native';

const currencyperrupee={
    Dollor: 0.014,
    Euro: 0.012,
    POUND: 0.011,
    RUBEL:0.93,
    AUSDOLLOR:0.2,
    CANDOLLAR:0.19,
    YEN:1.54,
    DINAR:0.0043,
    BITCOIN:0.000004,


}

const Home = ({route,navigation})=> {
    const User = route.params.myName;
    const[inputvalue, setinputValue] = useState(0);
    const[resultValue, setResultValue] = useState(0);
    const buttonpress=(currency)=>{
        if(! inputvalue){
            // return Snackbar.show({
            //     text:"enter a value",
            //     backgroundColor:"#120E43",
            //     textcolor:"#FFFFFF",
            // });
            Alert.alert("enter a value")
        }
        
        let result=parseFloat(inputvalue) * currencyperrupee [currency]
        setResultValue (result.toFixed(2))
    }

    return(
        <>
        <ScrollView backgroundColor={"#7b68ee"}
        KeyboardShouldPersistTaps="handled">
            <Text style={styles.Title}> Welcome {User}</Text>
            <SafeAreaView style ={styles.container}>
                <View style ={styles.resultcontainer}>
                    
                    <Text style={styles.resulttext}>{resultValue}</Text>
                </View>
                <View style={styles.inputcontainer}>
                    <TextInput 
                    style={styles.input}
                    keyboardType={'numeric'}
                    placeholder="EnterValue"
                    placeholderColor="#FFFFFF"
                    value={inputvalue}
                    onChangeText={(inputvalue)=>setinputValue(inputvalue)}>
                      
                    </TextInput>
                </View>
                <View style={styles.coverterButtoncontainer}>
                    {Object.keys(currencyperrupee).map((currency)=>(
                        <TouchableOpacity
                        onPress={()=>buttonpress(currency)}
                        Key={currencyperrupee}
                        style={styles.converterbutton}
                        >
                            <Text style={styles.buttontext}>{currency}</Text>

                        </TouchableOpacity>
                    ))}

                </View>
                <View style={styles.coverterButtoncontainer}>
                    <TouchableOpacity
                        onPress={()=>{setResultValue(0),setinputValue(0)}}
                        style={styles.converterbutton}
                        >
                            <Text style={styles.buttontext}>Clear</Text>

                        </TouchableOpacity>
                    

                </View>
            </SafeAreaView>

        </ScrollView>

        </>
    )
  
}


const styles =StyleSheet.create({
    container:{
        flex: 1,
        
    },
    Title:{
        fontSize:30,
        color:"#fff",
        textAlign:"center",
        fontWeight:"bold",
        marginTop:5,
    },
    resultcontainer:{
        height:70,
        marginTop:30,
        justifyContent:"center",
        alignItems:"center",
        borderWidth:4,
        borderRadius:12,
        
        
    },
    resulttext:{
        marginTop:4,
        fontSize:30,
        color:"#FFFFFF",
        fontWeight:"bold"

    },
    inputcontainer:{
        height:70,
        marginTop:10,
        justifyContent:"center",
        alignItems:"center",
        borderWidth:4,
        borderRadius:12,
    },
    input:{
        color:"#FFF",
        fontSize:20,
        fontWeight:"bold",
        textAlign:"center"
    },
    coverterButtoncontainer:{
    
        flexDirection:"row",
        flexWrap:"wrap",
        marginTop:10,
        justifyContent : "space-around"
        
    },
    converterbutton:{
        justifyContent:"center",
        alignItems:"center",
        height:100,
        width:"30%",
        borderWidth:2,
        marginBottom : 5,
        borderRadius:10,
        

    },
    buttontext:{
        color:"#FFF",
    }

})
export default Home;
